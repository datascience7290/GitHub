install.packages("caret")
setwd('/Users/hinagandhi/desktop/random_forest_classification')
install.packages("randomForest")
set.seed(123)
building_id <- NULL
confusion_matrix_random <- NULL
#length(obj_name_power)
for(i in 1:nrow(obj))
{
i <- 1
data <- as.data.frame(list_dataframes_x[[i]])
colnames(data)[12] <- "dayofweek"
library(ggplot2)
base_hr_class ~ TemperatureF + hour + dayofweek + Weekday + 
  month + Holiday + Consumption + area_floor._m.sqr + Dew_PointF + 
  Humidity + Sea_Level_PressureIn + VisibilityMPH + Wind_SpeedMPH + 
  WindDirDegrees
name <- paste0("buildingID_",data$BuildingID[i],"_meternumb_",data$meternumb[i])
data$base_hr_class <- as.factor(data$base_hr_class)
data <- data[,c(23,7,12,10,14,11,15,8,17,25:31)]
library(randomForest)
table(data$base_hr_class)/nrow(data)
#High          Low 
#0.5353793691 0.4646206309

#53% of the observations has target variable âHighâ and remaining 46% observations take value âLowâ.

#Now, we will split the data sample into development and validation samples.

sample.ind <- sample(2, 
                     nrow(data),
                     replace = T,
                     prob = c(0.6,0.4))
cross.sell.dev <- data[sample.ind==1,]
cross.sell.val <- data[sample.ind==2,]

table(cross.sell.dev$base_hr_class)/nrow(cross.sell.dev)
#        High          Low 
#0.5331720105 0.4668279895  

table(cross.sell.val$base_hr_class)/nrow(cross.sell.val)
#High          Low 
#0.5387453875 0.4612546125 

class(cross.sell.dev$base_hr_class)

## [1] "factor"

varNames <- names(cross.sell.dev)
# Exclude ID or Response variable
varNames <- varNames[!varNames %in% c("base_hr_class")]

# add + sign between exploratory variables
varNames1 <- paste(varNames, collapse = "+")

# Add response variable and convert to a formula object
rf.form <- as.formula(paste("base_hr_class", varNames1, sep = " ~ "))

cross.sell.rf <- randomForest(rf.form,
                              cross.sell.dev,
                              ntree=500,
                              importance=T)

plot(cross.sell.rf)

# Variable Importance Plot
varImpPlot(cross.sell.rf,
           sort = T,
           main="Variable Importance",
           n.var=5)

# Variable Importance Table
var.imp <- data.frame(importance(cross.sell.rf,
                                 type=2))
# make row names as columns
var.imp$Variables <- row.names(var.imp)
var.imp[order(var.imp$MeanDecreaseGini,decreasing = T),]

# Predicting response variable
cross.sell.dev$predicted.response <- predict(cross.sell.rf ,cross.sell.dev)

#Confusion Matrix

#confusionMatrix function from caret package can be used for creating confusion matrix based on actual response variable and predicted value.

# Load Library or packages
library(e1071)
library(caret)
## Loading required package: lattice
## Loading required package: ggplot2
# Create Confusion Matrix
confusionMatrix(data=cross.sell.dev$predicted.response,
                reference=cross.sell.dev$base_hr_class,
                positive='LOW')

# Predicting response variable
cross.sell.val$predicted.response <- predict(cross.sell.rf ,cross.sell.val)

# Create Confusion Matrix
output <- confusionMatrix(data=cross.sell.val$predicted.response,
                reference=cross.sell.val$base_hr_class,
                positive='LOW')
cross.sell.val <- cross.sell.val[order(cross.sell.val$Month,cross.sell.val$Day,cross.sell.val$hour),]
count <- 0
day <- cross.sell.val$Day[1]
for(i in 1:nrow(cross.sell.val))
{
  if(cross.sell.val$Day == day )
  {
  if(cross.sell.val$predicted.response[i]!= cross.sell.val$base_hr_class[i])
  {count <- count+1}
  if(count >= 6)
  {cross.sell.val$Outlier_day[i] <- "TRUE"}else
  {cross.sell.val$Outlier_day[i] <- "FALSE"}
  }else{count <- 0}
  day <- cross.sell.val$Day
}
library(ROCR)
cross.forest = predict(cross.sell.rf,newdata = cross.sell.val)
forestpred = prediction(cross.forest, cross.sell.val$base_hr_usage)
forestperf = performance(forestpred,measure = "tpr", x.measure = "fpr")
plot(perf)
name_dataframe <- NULL
building_id$name <- name
write.csv(cross.sell.val,paste0(name,"_prediction_",".csv"))
write.csv(output[2],paste0(name,".csv"))
}

