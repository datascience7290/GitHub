setwd('/Users/hinagandhi/desktop/knn_classification')
library(gmodels)
library(ROCR)
confusion_matrix_knn <- NULL
building_id <- NULL

denormalize <- function(x) {
  return ((x * (max(x) - min(x))) + min(x))
}
predicted_values_knn <- NULL
#ROC curve
#prediction <- prediction(test.probs, test$ynaffair)
#performance <- performance(prediction, measure = "tpr", x.measure = "fpr")
for(i in 1:length(obj_name_power))
{
i <- 1  
data_knn <- as.data.frame(list_dataframes_x[[i]])

data_knn$base_hr_class[data_knn$base_hr_class == 'LOW'] <- 0
data_knn$base_hr_class[data_knn$base_hr_class == 'HIGH'] <- 1

data_knn$base_hr_class <- as.numeric(data_knn$base_hr_class)

name <- paste0("buildingID_",data_knn$BuildingID[i],"_meternumb_",data_knn$meternumb[i])
#View(data_knn)
drops <- c("BuildingID","vac", "meternumb","type","date","Holiday",
           "Base_hour_Flag","Address","FloorArea_mSqr","Latitude","Longitude","nearestAirport",
           "Conditions","Wind_Direction","Events","Year","X.x","X.y","kwh_per_meter_sq")
data_knn <- data_knn[ , !(names(data_knn) %in% drops)]
names(data_knn)
str(data_knn)
head(data_knn)
#View(data_knn)
table(data_knn$base_hr_class)

#Mix up dataset#
set.seed(1)
group<- runif(nrow(data_knn))
data_knn<- data_knn[order(data_knn$hour,data_knn$Day,data_knn$Month),]
summary(data_knn[, c(1:14)])
#View(data_knn)
#Normalization#
normalize<-function(x)(return((x-min(x))/(max(x)-min(x))))
data_knn_n <- NULL
data_knn_n <- subset(data_knn, select=c(1:7,9:16))
#data_knn_n<-as.data.frame(lapply(data_knn[,c(1,4,9:16)]))

summary(data_knn_n)
#View(data_knn_n)
#Separate training&testing dataset
length_1 <- nrow(list_dataframes_x[[i]])
length_2 <- nrow(list_dataframes_x[[i]])/2
data_knn_n_train<-data_knn_n[1:length_2, ]
data_knn_n_test<-data_knn_n[(length_2+1):length_1, ]
data_knn_train_target<-data_knn[1:length_2,8]
data_knn_test_target<-data_knn[(length_2+1):length_1,8]

# fit in knn algorithm
require(class)
m1<- knn(train= data_knn_n_train, test= data_knn_n_test, cl=data_knn_train_target, k=92)
output <- table(data_knn_test_target,m1)

#roc
library(ROCR)
p <- prediction(data_knn_test_target, m1)
prf <- performance(p, measure = "tpr", x.measure = "fpr")
plot(prf)

auc <- performance(p, measure = "auc")
auc <- auc@y.values[[1]]
auc

View(data_knn_n_test)

#lift curve

#install.packages("gmodels")
data_knn_n_test$predicted_Value <- m1 
data_knn_n_test$actual_value <- data_knn_test_target
#View(data_knn_n_test)
data_knn_n_test <- data_knn_n_test[order(data_knn_n_test$Month,data_knn_n_test$Day,data_knn_n_test$hour),]
count <- 0
for(i in seq(from=1, to=nrow(data_knn_n_test), by=12))
{
  if(data_knn_n_test$predicted_Value[i]!= data_knn_n_test$actual_value[i])
  {count <- count+1}
  if(count >= 6)
    {data_knn_n_test$Outlier_day[i:(i+11)] <- "TRUE"}else
    {data_knn_n_test$Outlier_day[i:(i+11)] <- "FALSE"}
}
#result and comparison 
#confusion_matrix_knn[[i]] <- output
name_dataframe <- NULL
building_id$name <- name
confusion_matrix_knn <- rbind(confusion_matrix_knn,building_id,output)
write.csv(data_knn_n_test,paste0(name,".csv"), row.names=FALSE)
y <- CrossTable(x=data_knn_test_target, y=m1, prop.chisq = FALSE)
}
write.csv(confusion_matrix_knn, "confusion_matrix_knn.csv", row.names=FALSE)